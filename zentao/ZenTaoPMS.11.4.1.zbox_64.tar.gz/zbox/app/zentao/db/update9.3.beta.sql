alter table zt_bug modify column mailto text;
alter table zt_story modify column mailto text;
alter table zt_task modify column mailto text;
alter table zt_testtask modify column mailto text;
