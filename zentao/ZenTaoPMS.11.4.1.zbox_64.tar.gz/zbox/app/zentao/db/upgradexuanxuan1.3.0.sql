ALTER TABLE `zt_im_message` CHANGE `order` `order` BIGINT(8) UNSIGNED NOT NULL;
