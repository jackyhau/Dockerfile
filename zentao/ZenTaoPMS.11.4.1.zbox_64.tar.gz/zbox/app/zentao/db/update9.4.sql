alter table zt_taskestimate modify column work text;
