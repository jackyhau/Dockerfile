ALTER TABLE `zt_story` ADD `sourceNote` varchar(255) COLLATE 'utf8_general_ci' NOT NULL AFTER `source`;
