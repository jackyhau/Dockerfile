UPDATE `zt_block` SET `grid` = 8 WHERE `block` IN ('statistic', 'flowchart', 'welcome');
UPDATE `zt_block` SET `grid` = 4 WHERE `block` = 'overview';
